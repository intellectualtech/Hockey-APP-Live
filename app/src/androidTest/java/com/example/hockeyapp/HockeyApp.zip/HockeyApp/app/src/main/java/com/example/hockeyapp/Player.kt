package com.example.hockeyapp

data class Player(
    val name: String = "",
    val age: Int = 0,
    val position: String = "",
    val team: String = ""
)
